jpg/recover.c

Recovers JPEG images from a forensic image.
