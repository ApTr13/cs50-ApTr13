Developed a game with a graphical user interface
atop the Stanford Portable Library 

Design included user options such as number, color, lives
and size of bricks. The ball movement was implemented with 
a random angle trajectory after a hit.
