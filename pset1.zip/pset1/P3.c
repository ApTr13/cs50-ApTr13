#include <cs50.h>
#include <stdio.h>
#include <math.h>

int main(void)
{
    int f = 13195;
    for (int i = 13194; i > 1; i--)
    {
        f /=i;
    }
    printf ("%d\n", f);
}
