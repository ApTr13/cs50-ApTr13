/* 
* Made By - ApTr13
* apurvatripathi13@gmail.com
*/
#include <stdio.h>

int main(void)
{
    printf("hello, world\n");
}
