The Game of Fifteen (generalized to d x d)
